<div class="notice notice-error"><p><?php
        /**
         * ONG Store
         *
         * Licence: MIT https://opensource.org/licenses/MIT
         * Copyright: odokienko
         */
        echo $message; ?></p></div>