<?php
/**
 * ONG Store
 *
 * Licence: MIT https://opensource.org/licenses/MIT
 * Copyright: odokienko
 */
/**
 * ONG search template
 */

get_header(); ?>

    <section id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <div class="os-page-container"></div>
        </main>
    </section>


<?php get_sidebar(); ?>
<?php get_footer(); ?>