<?php
/**
 * @package PNixx.Pagination
 * @author  Sergey Odintsov <nixx.dj@gmail.com>
 * @license http://opensource.org/licenses/mit-license.php (MIT License)
 */

namespace OngStore\FacetedFilter\Helper\Pagination;

class Exception extends \Exception {

}
